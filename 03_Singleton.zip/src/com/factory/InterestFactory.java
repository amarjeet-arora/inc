package com.factory;

import java.util.HashMap;
import java.util.Map;

import com.model.FDAccountCalculator;
import com.model.InterestCalculator;
import com.model.SavingAccountInterestCalculator;

 
public class InterestFactory {
	private static Map<String , InterestCalculator> maps;
	static{
		maps=new HashMap<String, InterestCalculator>();
		maps.put("s", new SavingAccountInterestCalculator());
		maps.put("f", new FDAccountCalculator());
	}
	public static InterestCalculator create(String type){
		System.out.println(maps.get(type));
		return maps.get(type);
	}
	private InterestFactory(){}
}
