package singletonsExample_1;

public class Database {
	private static Database singleObject;
	private int record;
	private String name;

	public String getName() {
		return name;
	}

	private Database(String n) {
		name = n;
		record = 0;
	}

	public static Database getInstance(String n) {
		if (singleObject == null) {
			System.out.println("nothing");
			singleObject = new Database(n);
			

		}
		System.out.println("something");
		return singleObject;
	}
}
