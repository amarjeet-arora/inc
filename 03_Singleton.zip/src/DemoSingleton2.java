import java.io.Serializable;

public class DemoSingleton2 implements Serializable {
    private volatile static DemoSingleton2 instance = null;
 
    public static DemoSingleton2 getInstance() {
        if (instance == null) {
            instance = new DemoSingleton2();
        }
        return instance;
    }
 
    protected Object readResolve() {
        return instance;
    }
 
    private int i = 10;
 
    public int getI() {
        return i;
    }
 
    public void setI(int i) {
        this.i = i;
    }
}