package com.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User {
@Id
	private int empId;
	public User(int empId, String empName, String empCity) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empCity = empCity;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	private String empName;
	private String empCity;
	@Override
	public String toString() {
		return "User [empId=" + empId + ", empName=" + empName + ", empCity=" + empCity + "]";
	}
	
}
