package com.mypack.bootapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UserDao;
import com.entity.User;

@Service
public class UserService {
	@Autowired
	private UserDao userDao;
	
	public boolean validate(String uname,String pass) {
		
		if(uname.equals("admin") && pass.equals("manager")) {
		
		
		return true;
	}
		else {
			return false;
		}
	 

	}
	
public boolean addUser(User user) {
	
	if(user!=null) {
		userDao.save(user);
		return true;
	}
	else {
		return false;
	}
}





}
