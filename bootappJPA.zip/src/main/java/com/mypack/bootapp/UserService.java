package com.mypack.bootapp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;

import com.dao.UserDao;
import com.entity.User;

@Service
public class UserService {
	@Autowired
	private UserDao userDao;
	
	public boolean validate(String uname,String pass) {
		
		if(uname.equals("admin") && pass.equals("manager")) {
		
		
		return true;
	}
		else {
			return false;
		}
	 

	}
	@CacheEvict(value="user",allEntries = true)
public boolean addUser(User user) {
	
	if(user!=null) {
		userDao.save(user);
		return true;
	}
	else {
		return false;
	}
	
	
	
	
}
@Cacheable(value="user")
public List<User> findAll(){
	System.out.println("inside find function");
	
	 List<User> lst=(List<User>) userDao.findAll();
	 for (Object ob: lst) {
		 System.out.println(ob);
	 }
	return lst;
	 
	
	
}






}
