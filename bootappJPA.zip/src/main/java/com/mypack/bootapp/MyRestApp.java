package com.mypack.bootapp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.entity.User;

@Controller
@RequestMapping("/myapp")
public class MyRestApp {
	@Autowired
	private UserService userService;
	@GetMapping("/sayhello")
	
	@ResponseBody
	public String sayHello() {
		
		
		return " welcome to my rest app";
	}
@GetMapping("/login")
	
	//@ResponseBody
	public String login() {
		return "login";
	}
@PostMapping("/login")
@ResponseBody
public String loginCheck(@RequestParam("uname")String name,@RequestParam("pass")String pass) {
	
	
	if(userService.validate(name, pass)) {
		return "successfully validated";
	}
	return "error";
	
}
	
@GetMapping("/register")

 
public String register() {
	return "register";
}
	
@PostMapping("/register")

@ResponseBody
public String registerUser(@RequestParam("uid")int uid,@RequestParam("uname")String uname,@RequestParam("city")String city) {
	User user= new User(uid, uname, city);
	if(userService.addUser(user)) {
		return "user addded sucessfully";
	}else {
	return "register failed";
}
}
@GetMapping("/findall")
@ResponseBody
public List<User> findAll(){
	return userService.findAll();
}
	

}
